Riley Roth
CSC310 
Homework 5 READ_ME 

Note that I included min_stack class from homework 3. In this program, it just
functions as a stack. I only use the push and pop methods in the classes for 
this code, so I will not include this in the README.

class hanoi
	data members:
		min_stack a, b, c
			These stacks represent the three pegs.
		int size
			This holds the number of rings on the pegs.
		int step
			This holds the number of steps done in solve() to show
			that the program uses the minimum number of steps.
	
	hanoi(int n)
		This method is a constructor that initializes a, b, and c as 
		min_stacks. It also sets size as n. Then, it places the n rings
		in order on peg a.

	solve()
		This method solves the problem and outputs each step in the 
		process. This is also a helper method that displays the initial 
		state of the pegs and rings. Then, it calls the full method for 
		num = size, init = a, aux = b, and goal = c.

	solve(int num, min_stack init, min_stack aux, min_stack goal)
		Here, num represents the number of rings being moved. init 
		represents the initial peg that the rings are on. aux represents
		the auxillary peg. goal represents the peg that we move num rings
		to. This method is recursive, using solve() to move num - 1 rings
		to aux, moving the num ring to the goal, then moving the num - 1
		rings to goal (above the num ring). The base case is when num = 0,
		and nothing happens in this case.

	move_ring(min_stack s, min_stack e)
		Here, s represents a peg with a ring on it, and e represents the 
		peg we are moving a ring to. This method prints which ring is 
		being moved, which peg it is being moved from, and which peg it 
		is being moved to. Then, the ring is popped from s and pushed to
		e and the state of the three pegs is printed.

	output_towers()
		This method prints the state of all three towers.

class traverse
	This class would typically use tree nodes and tree objects, but I wrote it
	so that none of that is necessary. Essentially, it is able to read an 
	array as a tree, so no other class is needed.	

	data members:
		String[] tree
			This array holds the array that contains the tree.
		String[] inorder_traverse
			This array holds the order that tree should be traversed
			for an inorder traverse.
		String[] preorder_traverse
			This array holds the order that tree should be traversed 
			for an inorder traverse.
		int iter_i
			This is an iterator used for inorder() method.
		int iter_p
			This is an iterator used for preorder() method.

	traverse(String[] x)
		This constructor initializes tree as x, then initializes 
		inorder_traverse and preorder_traverse as the size of x.
	
	inorder()
		This helper method initializes iter_i at 0 and returns the private
		inorder method on tree.

	inorder(String[] x)
		This method will assign the order of an inorder traverse to the 
		array inorder_traverse. This method is recursive. Its base
		case is when the size of x is 1, and assigns the only element of
		x to the next possible element of inorder_traverse. If x has a 
		size that is not 1, then the following happens: call inorder() on
		the left subtree, assign the root to inorder_traverse, then call
		inorder() on the right subtree. After everything else, this method
		returns inorder_traverse.

	preorder()
		This is a helper method that initializes iter_p and returns the 
		preorder method on tree.

	preorder(String[] x)
		This works almost the same as inorder(). The base case is when
		the length of x is 1, where the element in x is assigned to the
		next availible space in preorder_traverse. Otherwise, it assigns 
		the root of x to preorder_traverse, calls preorder() on the left
		subtree, and calls preorder() on the right subtree. After 
		everything else, it returns preorder_traverse.

	fix_notation(String[] x)
		This is a static method that fixes the notation of x to fit the 
		program. This is not necessary, but helps allow for a wider range
		of user input. Every tree should be of length 2^n - 1 to be fully
		correct. So, this method finds the first n value that makes 
		2^n - 1 >= the length of x. If this number is equal to the length
		of x, just return x. If not, make a new array, and copy all values
		of x into this array. Then fill the rest of the elements as null.
		Finally, this result is returned.

	left_subtree(String[] x)
		This method takes an array that contains a tree and returns the 
		left subtree of the tree as an array. This requires a integer 
		count to keep track of how many items have been added to the
		left subtree. Then, an integer skip is needed to know how many 
		iterations of a for loop to skip. Another int r_i keeps track of 
		the next availible index of the left subtree array. The array
		result holds the left subtree itself. 
		The tree x is iterated through, each element into result. When 
		count is not equal to skip, count is incremented. When count is 
		equal to skip, the next skip elements of x are skipped. Also, 
		skip is multiplied by two, and count is reinitialized at 1. In the
		end, result is returned.

	right_subtree(String[] x)
		This method is very similar to left_subtree, but returns the 
		right subtree. It uses the exact same data members. 
		The tree x is iterated through. When count is equal to skip, 
		the next skip - 1 elements are skipped (iterator increases by one
		again in the for loop, so this is why we subtract 1). Then, skip
		is doubled, and count is reinitialized at 1. When count is not 
		equal to skip, the corresponding element in x is assigned to the 
		next availible element of result, and count is incremented. 
		Finally, the result is returned.

	print_inorder()
		This prints inorder_traverse in a friendly way. preorder_traverse
		may contain null elements, so these elements are ignored while
		printing preorder_traverse.

	print_preorder()
		This is just like print_inorder() but for preorder_traverse.
