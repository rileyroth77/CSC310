class circular_queue

	Data members: 
		f - holds index of front
		r - holds index of rear + 1
		n - holds max size of queue
		empty - holds boolean of whether queue is empty
		queue - holds the actual queue

	circular_queue(int k)
		Takes an int value, and initializes an array of size k for the 
		queue. Also, it sets f at 0, r at 0, n at k, and empty at true.

	size()
		Returns the current size of the queue;

	is_empty()
		Returns boolean value of whether the queue is empty or not.

	is_full()
		Returns boolean value of whether the queue is full or not.

	get_front()
		Returns front value in queue.

	get_rear()
		Returns rear value in queue.

	delete_front()
		Deletes front value in queue.

	delete_rear()
		Deletes rear value in queue.

	insert_front(int k)
		Adds a value at the front.

	insert_rear(int k)
		Adds a value at the rear.

	output()
		Outputs queue, as well as the front and rear indexes.




class node

	Data members:
		num - holds some integer value
		next - holds another node

	node(int n)
		This initializes the node with num as n and next as null.

	next(node x)
		This changes the next node.



class linked_list
	
	Data members:
		start - holds the starting node.
		size - holds how many values are already in the list

	linked_list()
		Initializes a list with its first value as 0.

	linked_list(int n)
		Initializes a list with its first value as n.

	add_tail(int n)
		Adds a new tail with value n.

	delete_tail()
		Deletes the current tail.

	merge()
		Takes two sorted linked_lists and merges them into a sorted 
		linked_list.

	print_list()
		Prints the list.




class list_queue extends linked_list

	enqueue(int n)
		Adds value to the end of queue.
	
	dequeue()
		Deletes first node in queue and returns that node's value.

	len()
		Returns length of queue.

	first()
		Returns first value in queue.

	is_empty()
		Returns boolean of whether the queue is empty or not.

	search(int x)
		Returns boolean of whether x exists in the list.