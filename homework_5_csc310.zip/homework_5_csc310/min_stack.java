
package homework_5_csc310;

//The only thing I changed in this class is print_stack(), and I changed it to
//only output the stack itself, not the data members or minimum stack.

public class min_stack 
{
    //Note: to write these methods in constant time, there has to exist a 
    //maximum capacity for the stack.
    
    final int CAP = 20; //this is the capacity of the stack
    
    int[] stack = new int[CAP]; 
    //this establishes the object as an single dimensional int array
    
    int[] minimum = new int[CAP];
    //This establishes a stack that will hold minimum values to help multiple
    //methods run in constant time while also keeping track of the minimum.
    
    int min_int = 0; //this holds the current minimum
    int top_s = -1; //this holds the current last element in stack array
    //Note: if this is equal to -1, then there are no elements in the stack
    int top_m = -1; //this holds the current last element in minimmum array
    
    //I dont use a constructor because there really is not anything to initialize.
    
    int len() //returns length
    {
        return top_s + 1;
    }
    
    boolean is_empty() //returns whether stack is empty or not
    {
        return top_s == -1;
    }
    
    void push(int e) //adds new element to end of stack
    {
        if (top_s == (CAP - 1)) //exception when stack is at capacity
        {
            throw new IndexOutOfBoundsException("Cannot push more than 20 ints.");
        }
        if (top_s == -1) //When entering the first element in the stack
        {
            this.min_int = e;
            this.minimum[0] = e;
            top_m++;            
        }
        else if (this.min_int >= e) //When entering a new element and it is the minimum
        {
            min_int = e;
            this.minimum[++top_m] = e;
        }
        
        this.stack[++top_s] = e; //Always assign e to the next placeholder
    }
    
    int pop() 
    {
        int r; //return value
        
        if (top_s == -1) //when the stack is empty
        {
            throw new IllegalStateException("Stack is empty, cannot pop.");
        }
        
        if (this.stack[top_s] == min_int) //when popping the current minimum
        {
            //note: this case is why we have the minimum array in the first place
            //it holds the last minimum when the current minimum is popped.
            r = min_int;
            this.minimum[top_m--] = 0;
            if (top_m != -1)
                min_int = this.minimum[top_m]; 
            else
                min_int = 0;
        }
        
        else //otherwise, just assign the current top element of the stack to r
        {
            r = this.stack[top_s];
            
        }
        
        //Always assign the current top to 0 for garbage collection
        this.stack[top_s--] = 0;
        return r;
    }
    
    int top() //returns top element without removing it from the stack
    {
        if (top_s == -1)
        {
            throw new IllegalStateException("Stack is empty, no top.");
        }
        else
        {
            return this.stack[top_s];
        }
    }
    
    int get_min() //returns current min
    {
        return min_int;
    }
    
    void print_stack() //I rewrote this to only output the stack
    {
        for (int i = 0; i < this.stack.length; i++)
        {
            System.out.print(this.stack[i] + "  ");
        }
    }
}

