
package homework_5_csc310;

public class Homework_5_CSC310 
{
    
    public static void main(String[] args) 
    {
        //problem 1
        hanoi tower_1 = new hanoi(2);
        tower_1.solve();
        System.out.println("\n\n\n");
        hanoi tower_2 = new hanoi(3);
        tower_2.solve();
        System.out.println("\n\n\n");
        hanoi tower_3 = new hanoi(4);
        tower_3.solve();
        System.out.println("\n\n\n");
        
        
        //problem 2
        String[] w = new String[6];
        w[0] = "1";
        w[1] = null;
        w[2] = "2";
        w[3] = null;
        w[4] = null;
        w[5] = "3";
        //w = [1, null, 2, null, null, 3]
        traverse tr = new traverse(w);
        String[] y = tr.inorder();
        tr.print_inorder();
        String[] z = tr.preorder();
        tr.print_preorder();
        
                
        String[] x = new String[7];
        for (int i = 0; i < 7; i++)
        {
            x[i] = Integer.toString(i);
        }
        //x = [0, 1, 2, 3, 4, 5, 6]
        tr = new traverse(x);
        y = tr.inorder();
        tr.print_inorder();
        z = tr.preorder();
        tr.print_preorder();
        
        for (int i = 0; i < 7; i++)
        {
            if (i == 3 || i == 6)
            {
                x[i] = null;
            }
            else
            {
                x[i] = Integer.toString(i);
            }
        }
        //x = [0, 1, 2, null, 4, 5, null]
        tr = new traverse(x);
        y = tr.inorder();
        tr.print_inorder();
        z = tr.preorder();
        tr.print_preorder();
        
    }
}

class hanoi
{
    //I created a class so that I didn't have to manually write a stack class.
    //I simply copied and pasted min_stack from hw3 for simplicity.
    min_stack a, b, c; //note: min_stack is bounded in size, bounding our size at 20
    int size; //This holds the number of rings
    int step; //This keeps track of the number of steps done in solve()
    
    hanoi(int n) //This initializes the stacks and size, then populates a with n rings
    {
        a = new min_stack();
        b = new min_stack();
        c = new min_stack();
        size = n;
        for(int i = 0; i < n; i++)
        {
            a.push(n - i);
        }
    }
    
    void solve() //Call this to solve a hanoi object - helper method
    {
        //initialize step
        step = 0; 
        //output the initial state of all stacks
        System.out.println("Initial for n = " + size + ":"); 
        output_towers();
        //Then call the actual method
        solve(size, a, b, c); 
    }
    
    //This is where the actual solving happens.
    //num holds the number of rings, init holds the stack that you are moving 
    //rings from, goal holds the stack that you are moving rings to, and aux 
    //holds the other stack.
    private void solve(int num, min_stack init, min_stack aux, min_stack goal)
    {
        //base case: number of steps to solve tower of hanoi - 2^n - 1
        //if n = 0, then 2^0 - 1 = 1 - 1 = 0.
        //So 0 is our base case
        if (num > 0) 
        {
            //First, take all the rings on top of the num ring and move them to 
            //the aux stack.
            solve(num - 1, init, goal, aux);
            //Second, move the num ring to the goal stack.
            move_ring(init, goal);
            //Last, take the rings you just moved to the aux stack and place them
            //on top of the num ring in the goal stack.
            solve(num - 1, aux, init, goal);
        }
    }
    
    //This method moves a ring and outputs a lot of information on how it is 
    //being moved. The arguments are the starting stack and the ending stack.
    void move_ring(min_stack s, min_stack e)
    {
        //these just hold the names of stacks s and e.
        char from, to;
        
        //assign name to from
        if (s == a)
        {
            from = 'a';
        }
        else if (s == b)
        {
            from = 'b';
        }
        else
        {
            from = 'c';
        }
        
        //assign name to to
        if (e == a)
        {
            to = 'a';
        }
        else if (e == b)
        {
            to = 'b';
        }
        else
        {
            to = 'c';
        }
        
        //Output the step number (step), which ring is being moved (s.top()), and 
        //the starting and ending stacks names (from and to respectively)
        System.out.println("Step " + (++step) + ": Move ring " + s.top() + " from peg " 
                + from + " to peg " + to + ".");
        //Actually move the ring from s to e.
        e.push(s.pop());
        //Then output all the stacks to show what happened.
        output_towers();
    }
    
    //This could have been included in move_ring(), but I wrote it separately to 
    //check my code at any point. This just outputs all the stacks.
    void output_towers()
    {
        System.out.print("Peg a: ");
        a.print_stack();
        System.out.print("\nPeg b: ");
        b.print_stack();
        System.out.print("\nPeg c: ");
        c.print_stack();
        System.out.println("\n");
    }
}

class traverse //So this class takes care of all tree traversal - including nodes
{
    String[] tree; //This stores the tree in the form of an array.
    String[] inorder_traverse; //This stores the inorder traverse in an array.
    String[] preorder_traverse; //This stores the preorder traverse in an array.
    int iter_i = 0; //This iterates through tree for the inorder traverse
    int iter_p = 0; //This iterates through tree for the preorder traverse
    
    traverse(String[] x) 
    {
        tree = fix_notation(x); //Assign the tree to the corresponding array
        inorder_traverse = new String[tree.length]; //initialize size for the other arrays
        preorder_traverse = new String[tree.length];
    }
    
    String[] inorder() //Helper method for the tree traversal
    {
        return inorder(tree);
    }
    
    private String[] inorder(String[] x) //Here is the actual method
    {
        //base case: if tree is of length 1, add the element to inorder_traverse
        if (x.length == 1) 
        {
            inorder_traverse[iter_i++] = x[0];
        }
        //Otherwise, 
        else
        {
            //Traverse the left subtree.
            inorder(left_subtree(x));
            //Add the root to inorder_traverse
            inorder_traverse[iter_i++] = x[0];
            //Traverse the right subtree.
            inorder(right_subtree(x));
        }
        return inorder_traverse;
    }
    
    //preorder() is very similar to inorder()
    String[] preorder() //helper method
    {
        return preorder(tree);
    }
    
    String[] preorder(String[] x)
    {
        //base case: tree is of length 1, so add to preorder_traverse.
        if (x.length == 1)
        {
            preorder_traverse[iter_p++] = x[0];
        }
        //otherwise,
        else
        {
            //add the root to preorder_traverse.
            preorder_traverse[iter_p++] = x[0];
            //traverse the left subtree
            preorder(left_subtree(x));
            //traverse the right subtree
            preorder(right_subtree(x));
        }
        return preorder_traverse;
    }
    
    //This method just changes the notation slightly to fit the class better
    //essentially, it changes the input tree to size 2^n - 1 by filling extra 
    //space with null.
    static String[] fix_notation(String[] x)
    {
        int count = 1; //determines size of n for 2^n - 1
        String[] result; //holds fixed tree
        
        //count size that the array is supposed to be
        while (Math.pow(2, count) - 1 < x.length)
        {
            count++;
        }
        
        //size of result
        int new_len = (int)Math.pow(2, count) - 1;
        
        //if x is already in the correct notation, return it
        if (new_len == x.length)
        {
            return x;
        }
        
        //otherwise, initialize result to new_len
        result = new String[new_len];
        
        //copy x into result
        for(int i = 0; i < x.length; i++)
        {
           result[i] = x[i];
        }
        
        //fill the rest of result with null
        for (int i = x.length; i < new_len; i++)
        {
            result[i] = null;
        }
        
        return result;
    }
    
    //This will take a tree as an argument and return the left subtree as an array
    //This is kind of complicated to find how to skip the exact number of spaces
    static String[] left_subtree(String[] x) 
    {
        int count = 1; //This counts how many elements were added to result
        int skip = 1;  //When count = skip, I skip this number of elements of x
        int r_i = 0;   //This iterates through result
        x = fix_notation(x); //Fix the notation of x before doing anything else
        //Then this holds the left subtree. It will always be this size, as 
        //x.length - 1 takes out the root, and half of the rest is the right subtree
        String[] result = new String[(x.length - 1) / 2]; 
        
        //iterate through x
        for (int i = 1; i < x.length; i++)
        {
            //assign x[i] to result.
            result[r_i++] = x[i];
            //When count = skip,
            if (count == skip)
            {
                //skip this many places
                i += skip;
                //double size of skip (this is the pattern of how many we skip)
                skip *= 2;
                //reinitialize count at 1
                count = 1;
            }
            //Otherwise
            else
            {
                //increment count
                count++;
            }
        }
        return result;
    }
    
    //I slightly modified left_subtree() to get right_subtree().
    static String[] right_subtree(String[] x)
    {   
        //data members are the same as left_subtree()
        int count = 1;
        int skip = 1;
        int r_i = 0;
        x = fix_notation(x);
        String[] result = new String[(x.length - 1) / 2];
        
        //iterate through x
        for (int i = 1; i < x.length; i++)
        {
            //When count = skip,
            if (count == skip)
            {
                
                i += skip - 1;
                skip *= 2;
                count = 1;
            }
            else
            {
                result[r_i++] = x[i];
                count++;
            }
            
        }
        return result;
    }
    
    void print_inorder()
    {
        System.out.print("[ ");
        for (int i = 0; i < inorder_traverse.length; i++)
        {
            if(inorder_traverse[i] != null)
            {
                System.out.print(inorder_traverse[i] + " ");
            }
        }
        System.out.println("]");
    }
    
    void print_preorder()
    {
        System.out.print("[ ");
        for (int i = 0; i < preorder_traverse.length; i++)
        {
            if(preorder_traverse[i] != null)
            {
                System.out.print(preorder_traverse[i] + " ");
            }
        }
        System.out.println("]");
    }
}