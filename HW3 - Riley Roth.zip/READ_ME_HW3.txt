Riley Roth - CSC310 - Homework 3
READ_ME file - Documentation




Class min_stack

	This class contains data members:
	int[] stack - This holds the stack of integers.
	int[] minimum - This keeps track of the minimum number in stack.
			This is essential, as the current min may be popped.
	int CAP - This holds the maximum capacity of stack. Since this array
		  has a maximum size, methods can be written in constant time.
	int min_int - This holds the current minimum number in stack.
	int top_s - This holds the index of the top element in stack.
	int top_m - This holds the index of the top element in minimum.
	
	Class methods:
	int len()
		This returns the number of elements stored in stack.
	
	boolean is_empty()
		This returns a boolean value of whether elements are stored in 
		stack or not.
	
	void push(int e)
		This adds an element e to stack, all while keeping track of the 
		current minimum value.

	int pop()
		This removes the top element in the stack and returns it. This
		method keeps track of the current minimum element.

	int top()
		This returns the top element in the stack.

	int get_min()
		This returns the current minimum element in the stack.

	void printStack()
		This prints the elements in stack and minimum. It then prints
		min_int, top_s, and top_m. This was mainly used for debugging,
		and was not made in constant time.

class str_stack
	(I made this class because of methods in arithmetic_expression. An int 
	based stack is not enough for these methods.)
	
	This class contains data members:
	int CAP - This stores the maximum capacity of the stack.
	String[] stack - This array holds the stack.
	int top - This holds the current top of the stack.

	Class methods:
	int length()
		This method returns the number of elements in the stack.

	boolean is_empty()
		This method returns the boolean value of whether there are 
		elements in the stack or not.

	void push(String e)
		This method adds the element e to stack.

	String pop()
		This method removes the top element of the stack and returns it.

	String top()
		This method returns the top element of the stack.

	void output()
		This outputs the values in the stack. This is mainly used for 
		debugging, and does not run in constant time.
		


Class arithmetic_expression
	
	Class methods:
	static private int precedence(String op)
		This method will return an int value that can be used comparatively
		to determine the precedence of an operator. From highest to lowest,
		the order of operators are as follows:
			()
			*/
			+-
			other
		This method is private, as it should only be used in infix() and 
		postfix() to determine the precedence of operators as compared to
		other operators.

	static double infix(String e)
		This method will take a string that contains an arithmetic 
		expression in infix notation and evaluate it. It uses the
		Shunting-Yard Algorithm to convert infix to postfix, then 
		it uses postfix() to evaluate the expression.

	static double postfix(String e)
		This method will take a string that contains an arithmetic 
		expression in postfix notation and evaluate it. This uses an
		algorithm found on:
		https://www.geeksforgeeks.org/stack-set-4-evaluation-postfix-expression/
		Note that there was much more involved in the method than the
		pseudocode algorithm

	