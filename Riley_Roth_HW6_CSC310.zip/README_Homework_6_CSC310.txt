Riley Roth
CSC310
Homework 6 READ_ME

class pq_object

	This class essentially holds an object with a key and value for class priority_queue.
	
	Data members:
		int key
			This holds the key of the object.
		int value
			This holds the value of the object.
		boolean is_null
			This is an easy way to make placeholders, needed in the 
			priority_queue class.

	pq_object()
		This constructor initializes a new null pq_object.

	pq_object(int k, int v)
		This constructor initializes a new pq_object with key k and value v.

	static pq_object empty_pq()
		This returns a null pq_object.

	static object key_val(int k, int v)
		this returns a pq_object with key k and value v.


class priority_queue
	
	This sorted priority queue works circularly. It also holds a max number of elements 
	for the priority queue at once.

	Data members:
		pq_object[] pq
			This holds the priority queue itself.
		final int ARR_SIZE = 20
			This holds the overall size of the priority queue. 
		int size
			This holds the number of elements in the priority queue.
		int top
			This stores the index of the top element.
		int rear
			This stores the index of the rear element plus one.
	
	priority_queue()
		This constructor creates a new empty priority_queue object populated with 
		null pq_objects.

	void add(pq_object x)
		This adds a new element to the priority queue while preserving sorting order.
		It throws an error if the x is null or the priority queue is full. When the 
		priority queue is empty, it simply makes x the first element of the priority
		queue. Otherwise, it iterates through the priority queue and finds the index
		of where x should go in the priority queue. Then, it moves all the higher
		indexed pq_objects back one space.
	
	pq_object remove_min()
		This takes out the minimum value in the priority queue. Because this is a 
		sorted priority queue, this is always the first element in the priority 
		queue. It also throws an error when the priority queue is empty.

	static int[] insertion_sort(int[] a)
		This uses the priority queue as a way to sort an array. All the items in 
		the array are placed into the key of the pq_object, and the corresponding 
		index is placed into the value of the pq_object. Then, the minimum key is 
		removed and placed into back into the int array, sorted.

	void print_pq()
		This method simply prints the priority queue in order from top to rear.

class Heap

	For questions 2 and 3, it would be easiest to have a general heap class with 
	Min_Heap and Max_Heap subclasses. This way I have to write the least amount of code.
	
	Data members:
		int[] heap
			This is where the heap is stored. It is of length 255, which holds 
			heaps of up to depth 8.
		int size
			This holds the current size of the heap.

	Heap()
		This constructor initializes an empty heap.

	boolean is_empty()
		This method returns whether the heap is empty or not.

	int size()
		This method returns the current size of the heap.

	protected static int parent_index(int x, int size)
		This method is used in both subclasses of Heap, and simply makes methods
		easier to write (hence protected). It takes an index from the heap and the
		current size as arguments. If x is not within the heap, it throws an exception.
		If x is the root, it also throws an exception.



class Min_Heap extends Heap

	As mentioned earlier, this is a subclass of Heap. Max_Heap is also nearly an exact
	copy of Min_Heap, so I will go into less detail there. 

	Min_Heap()
		This initializes an empty Min_Heap.

	Min_Heap(int[] x)
		This initializes a Min_Heap object with an array. It uses the insert method 
		to enter each item in the array into the heap.

	void insert(int k)
		This method inserts a new element at the end of the heap, then upheaps until
		the properties of the heap are maintained. 

	int find_min()
		This method returns the root of the heap, because the root will always be 
		the minimum in a heap. If the heap is empty, an exception is thrown.
		
	void del_min()
		This method places the last element of the heap in the root's place and
		discards the root. Then, it downheaps until the properties of the heap are
		maintained.

	
	void upheap()
		This uses the method of upheaping to fix the order of a heap. It takes
		the last element of the heap and compares it to its parent. If it is less 
		than its parent, it switches places with its parent. This process is 
		continued until the child is less than the parent.

	void downheap()
		This uses the method of downheaping to fix the order of a heap. It takes the
		root of a heap and finds its children. It finds the smallest child, and if
		it is less than that child, it switches places with the child. This process
		is continued until the parent is greater than the child. 
	
	static Min_Heap build_heap(int[] n)
		This initializes a new Min_Heap with the int array n.

	private static int smaller_child(int lc, int[] hp, int size)
		This returns the index of a smaller child of a particular parent. It takes
		the index of a left child, the heap array, and the current size as arguments.
		It will find the smaller of the two indicies, and return this index.



class Max_Heap extends Heap

	This is almost an exact copy paste from the Min_Heap. I will not explain in as much
	detail, as the idea is exactly the same. Also, the heap sort for problem 3 is in 
	here.

	Max_Heap
		Initializes a new empty Max_Heap.

	Max_Heap(int[] x)
		Initializes a new Max_Heap object with an int array.

	void insert(intk)
		Inserts k into the heap, then updates.
	
	int find_max()
		Returns the max value of the heap.

	void del_max()
		This deletes the max value of the heap and updates.

	void upheap()
		This is an upheap that switches child and parent when child is greater than
		parent.

	void downheap()
		This is a downheap that switches a parent with its greatest child when the 
		parent is smaller than the child.

	static Max_Heap build_heap(int[] x)
		This returns a Max_Heap initialized with an int array.

	static int larger_child(int lc, int[] hp, int size)
		This returns the larger child of a parent.

	static int[] heap_sort(int[] k)
		This is the inplace heap sort. With a pre-built heap that self-updates, 
		all that needs to be done is place all elements of the array in the heap,
		then take the max and fill the array back up from the end to the beginning.
		Then return the sorted array.
	







